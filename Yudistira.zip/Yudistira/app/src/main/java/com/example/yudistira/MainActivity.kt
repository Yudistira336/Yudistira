package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnKeHalamanSelanjutnya = findViewById<Button>(R.id.btnKeHalamanSelanjutnya)
        val btnKeHalamanGambar = findViewById<Button>(R.id.btnKeHalamanGambar)
        val btnKembali = findViewById<Button>(R.id.btnKembali)

        btnKeHalamanSelanjutnya.setOnClickListener {
            val intent = Intent(this, SecondActivity::class.java)
            startActivity(intent)
        }

        btnKeHalamanGambar.setOnClickListener {
            val intent = Intent(this, ThirdActivity::class.java)
            startActivity(intent)
        }

        btnKembali.setOnClickListener {
            finish() // Menutup activity
        }
    }
}
